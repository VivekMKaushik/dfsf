// Mock data store for SAP Fiori Approval Dashboard

export type RequestStatus = "pending" | "approved" | "rejected" | "clarification"

export interface ApprovalRequest {
  id: string
  requestNumber: string
  requestType: string
  customerName: string
  requestedBy: string
  date: string
  description: string
  amount?: number
  status: RequestStatus
  tCode: string
}

export interface TCodeCategory {
  code: string
  name: string
  description: string
  icon: string
}

export const tCodeCategories: TCodeCategory[] = [
  {
    code: "ZSD_PRICE",
    name: "Price & Flexy Plan",
    description: "Price & Flexy Plan Request Approval",
    icon: "tag",
  },
  {
    code: "ZSD_WAIVER",
    name: "Waiver Request",
    description: "Waiver Request Approval",
    icon: "file-minus",
  },
  {
    code: "ZSD_CRMREQ",
    name: "Assignment/Name Change",
    description: "Assignment / Name Change Requests",
    icon: "user-pen",
  },
  {
    code: "ME28",
    name: "Exceptional PO",
    description: "Exceptional PO Approvals",
    icon: "shopping-cart",
  },
  {
    code: "ZSD_PAYPLANAPP",
    name: "Flexy Payment Plan",
    description: "Flexy Payment Plan Approval",
    icon: "credit-card",
  },
  {
    code: "ZSD_CANREQ",
    name: "Cancellation Request",
    description: "Cancellation Request Approval",
    icon: "x-circle",
  },
  {
    code: "ZSD_CANREQ_RE",
    name: "Advance Refund",
    description: "Advance Refund Request Approval",
    icon: "rotate-ccw",
  },
]

// Mock approval requests data
export const mockRequests: ApprovalRequest[] = [
  // ZSD_PRICE requests
  {
    id: "1",
    requestNumber: "PR-2024-001",
    requestType: "Price Adjustment",
    customerName: "ABC Corporation",
    requestedBy: "John Smith",
    date: "2024-04-28",
    description: "Request for 15% discount on bulk order of 500 units",
    amount: 25000,
    status: "pending",
    tCode: "ZSD_PRICE",
  },
  {
    id: "2",
    requestNumber: "PR-2024-002",
    requestType: "Flexy Plan Setup",
    customerName: "XYZ Industries",
    requestedBy: "Sarah Johnson",
    date: "2024-04-27",
    description: "New flexy payment plan for enterprise license",
    amount: 120000,
    status: "pending",
    tCode: "ZSD_PRICE",
  },
  {
    id: "3",
    requestNumber: "PR-2024-003",
    requestType: "Price Override",
    customerName: "Tech Solutions Ltd",
    requestedBy: "Mike Davis",
    date: "2024-04-26",
    description: "Special pricing for government contract",
    amount: 85000,
    status: "approved",
    tCode: "ZSD_PRICE",
  },
  // ZSD_WAIVER requests
  {
    id: "4",
    requestNumber: "WV-2024-001",
    requestType: "Late Fee Waiver",
    customerName: "Global Traders",
    requestedBy: "Emily Chen",
    date: "2024-04-28",
    description: "Waiver of late payment fee due to banking issues",
    amount: 1500,
    status: "pending",
    tCode: "ZSD_WAIVER",
  },
  {
    id: "5",
    requestNumber: "WV-2024-002",
    requestType: "Service Fee Waiver",
    customerName: "Metro Services",
    requestedBy: "Alex Turner",
    date: "2024-04-25",
    description: "First-time customer goodwill waiver",
    amount: 500,
    status: "rejected",
    tCode: "ZSD_WAIVER",
  },
  // ZSD_CRMREQ requests
  {
    id: "6",
    requestNumber: "CR-2024-001",
    requestType: "Name Change",
    customerName: "Old Company Name → New Brand Inc",
    requestedBy: "Legal Team",
    date: "2024-04-28",
    description: "Company rebranding - update all records",
    status: "pending",
    tCode: "ZSD_CRMREQ",
  },
  {
    id: "7",
    requestNumber: "CR-2024-002",
    requestType: "Account Assignment",
    customerName: "Regional Partners",
    requestedBy: "Sales Manager",
    date: "2024-04-27",
    description: "Reassign account to new territory manager",
    status: "clarification",
    tCode: "ZSD_CRMREQ",
  },
  // ME28 requests
  {
    id: "8",
    requestNumber: "PO-2024-001",
    requestType: "Emergency Purchase",
    customerName: "Internal - IT Department",
    requestedBy: "IT Manager",
    date: "2024-04-28",
    description: "Emergency server replacement - production critical",
    amount: 45000,
    status: "pending",
    tCode: "ME28",
  },
  {
    id: "9",
    requestNumber: "PO-2024-002",
    requestType: "Over-Budget PO",
    customerName: "Internal - Operations",
    requestedBy: "Operations Lead",
    date: "2024-04-26",
    description: "Equipment upgrade exceeds quarterly budget",
    amount: 78000,
    status: "pending",
    tCode: "ME28",
  },
  // ZSD_PAYPLANAPP requests
  {
    id: "10",
    requestNumber: "PP-2024-001",
    requestType: "Extended Payment Plan",
    customerName: "Startup Ventures",
    requestedBy: "Account Executive",
    date: "2024-04-28",
    description: "12-month payment plan for annual subscription",
    amount: 36000,
    status: "pending",
    tCode: "ZSD_PAYPLANAPP",
  },
  {
    id: "11",
    requestNumber: "PP-2024-002",
    requestType: "Modified Terms",
    customerName: "Enterprise Corp",
    requestedBy: "Finance Team",
    date: "2024-04-24",
    description: "Quarterly billing instead of monthly",
    amount: 180000,
    status: "approved",
    tCode: "ZSD_PAYPLANAPP",
  },
  // ZSD_CANREQ requests
  {
    id: "12",
    requestNumber: "CN-2024-001",
    requestType: "Service Cancellation",
    customerName: "Sunset Industries",
    requestedBy: "Customer Service",
    date: "2024-04-28",
    description: "Customer requested early termination of contract",
    amount: 15000,
    status: "pending",
    tCode: "ZSD_CANREQ",
  },
  // ZSD_CANREQ_RE requests
  {
    id: "13",
    requestNumber: "RF-2024-001",
    requestType: "Advance Refund",
    customerName: "Quality Foods",
    requestedBy: "Billing Team",
    date: "2024-04-28",
    description: "Refund of prepaid amount due to service downgrade",
    amount: 8500,
    status: "pending",
    tCode: "ZSD_CANREQ_RE",
  },
  {
    id: "14",
    requestNumber: "RF-2024-002",
    requestType: "Credit Application",
    customerName: "Digital Agency",
    requestedBy: "Account Manager",
    date: "2024-04-22",
    description: "Apply credit for service interruption",
    amount: 2200,
    status: "approved",
    tCode: "ZSD_CANREQ_RE",
  },
]

export function getRequestsByStatus(status: RequestStatus): ApprovalRequest[] {
  return mockRequests.filter((r) => r.status === status)
}

export function getRequestsByTCodeAndStatus(
  tCode: string,
  status: RequestStatus
): ApprovalRequest[] {
  return mockRequests.filter((r) => r.tCode === tCode && r.status === status)
}

export function getRequestById(id: string): ApprovalRequest | undefined {
  return mockRequests.find((r) => r.id === id)
}

export function getStatusCounts(): Record<RequestStatus, number> {
  return {
    pending: mockRequests.filter((r) => r.status === "pending").length,
    approved: mockRequests.filter((r) => r.status === "approved").length,
    rejected: mockRequests.filter((r) => r.status === "rejected").length,
    clarification: mockRequests.filter((r) => r.status === "clarification").length,
  }
}

export function getTCodeStatusCounts(
  tCode: string
): Record<RequestStatus, number> {
  const filtered = mockRequests.filter((r) => r.tCode === tCode)
  return {
    pending: filtered.filter((r) => r.status === "pending").length,
    approved: filtered.filter((r) => r.status === "approved").length,
    rejected: filtered.filter((r) => r.status === "rejected").length,
    clarification: filtered.filter((r) => r.status === "clarification").length,
  }
}

export function getCategoryCountsByStatus(
  status: RequestStatus
): Record<string, number> {
  const counts: Record<string, number> = {}
  tCodeCategories.forEach((cat) => {
    counts[cat.code] = mockRequests.filter(
      (r) => r.tCode === cat.code && r.status === status
    ).length
  })
  return counts
}
