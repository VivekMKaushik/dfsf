"use client"

import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  Clock,
  CheckCircle,
  XCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { useState } from "react"
import type { RequestStatus } from "@/lib/store"
import { tCodeCategories, getTCodeStatusCounts } from "@/lib/store"

interface TCodeDetailScreenProps {
  tCode: string
  onBack: () => void
  onSelectStatus: (status: RequestStatus) => void
}

const statusConfig = {
  pending: {
    label: "Pending",
    icon: Clock,
    bgClass: "bg-status-pending",
    textClass: "text-status-pending",
    borderClass: "border-status-pending/30",
  },
  approved: {
    label: "Approved",
    icon: CheckCircle,
    bgClass: "bg-status-approved",
    textClass: "text-status-approved",
    borderClass: "border-status-approved/30",
  },
  rejected: {
    label: "Rejected",
    icon: XCircle,
    bgClass: "bg-status-rejected",
    textClass: "text-status-rejected",
    borderClass: "border-status-rejected/30",
  },
  clarification: {
    label: "Clarification Required",
    icon: HelpCircle,
    bgClass: "bg-status-clarification",
    textClass: "text-status-clarification",
    borderClass: "border-status-clarification/30",
  },
}

export function TCodeDetailScreen({
  tCode,
  onBack,
  onSelectStatus,
}: TCodeDetailScreenProps) {
  const [expandedStatus, setExpandedStatus] = useState<RequestStatus | null>(
    "pending"
  )
  const category = tCodeCategories.find((c) => c.code === tCode)
  const counts = getTCodeStatusCounts(tCode)
  const totalCount = Object.values(counts).reduce((a, b) => a + b, 0)

  const toggleExpand = (status: RequestStatus) => {
    setExpandedStatus(expandedStatus === status ? null : status)
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b bg-card px-4 py-3 shadow-sm">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-base font-semibold text-foreground">
                {category?.name || tCode}
              </h1>
            </div>
            <p className="text-xs text-muted-foreground">
              {category?.description}
            </p>
          </div>
        </div>
      </header>

      {/* T-Code Badge */}
      <div className="border-b bg-card px-4 py-3">
        <div className="flex items-center justify-between">
          <span className="rounded-md bg-primary/10 px-3 py-1 font-mono text-sm font-medium text-primary">
            {tCode}
          </span>
          <span className="text-sm text-muted-foreground">
            {totalCount} total {totalCount === 1 ? "request" : "requests"}
          </span>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4">
        <div className="space-y-3">
          {(Object.keys(statusConfig) as RequestStatus[]).map((status) => {
            const config = statusConfig[status]
            const Icon = config.icon
            const count = counts[status]
            const isExpanded = expandedStatus === status

            return (
              <div
                key={status}
                className={`overflow-hidden rounded-xl border-2 bg-card transition-all ${config.borderClass}`}
              >
                {/* Collapsible Header */}
                <button
                  className="flex w-full items-center gap-3 p-4"
                  onClick={() => toggleExpand(status)}
                >
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-lg ${config.bgClass}`}
                  >
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="font-medium text-foreground">
                      {config.label}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {count} {count === 1 ? "request" : "requests"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold text-white ${config.bgClass}`}
                    >
                      {count}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                </button>

                {/* Expandable Content */}
                {isExpanded && count > 0 && (
                  <div className="border-t px-4 pb-4 pt-3">
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => onSelectStatus(status)}
                    >
                      View {count} {config.label} {count === 1 ? "Request" : "Requests"}
                    </Button>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </main>
    </div>
  )
}
