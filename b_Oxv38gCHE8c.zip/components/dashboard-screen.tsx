"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import {
  LogOut,
  Bell,
  Tag,
  FileMinus,
  UserPen,
  ShoppingCart,
  CreditCard,
  XCircle,
  RotateCcw,
} from "lucide-react"
import { tCodeCategories, getTCodeStatusCounts } from "@/lib/store"

interface DashboardScreenProps {
  onSelectCategory: (tCode: string) => void
  onLogout: () => void
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  tag: Tag,
  "file-minus": FileMinus,
  "user-pen": UserPen,
  "shopping-cart": ShoppingCart,
  "credit-card": CreditCard,
  "x-circle": XCircle,
  "rotate-ccw": RotateCcw,
}

export function DashboardScreen({
  onSelectCategory,
  onLogout,
}: DashboardScreenProps) {
  const getTotalPendingCount = () => {
    return tCodeCategories.reduce((total, category) => {
      const counts = getTCodeStatusCounts(category.code)
      return total + counts.pending
    }, 0)
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Premium Header */}
      <header className="sticky top-0 z-10 bg-gradient-to-r from-primary to-primary/80 px-4 py-5 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/20 backdrop-blur-sm">
              <Image
                src="/prestige-logo.png"
                alt="Prestige"
                width={24}
                height={24}
                className="rounded"
              />
            </div>
            <div>
              <h1 className="text-base font-bold text-white">Approval Center</h1>
              <p className="text-xs text-white/75">Welcome back, Manager</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="relative text-white hover:bg-white/20"
            >
              <Bell className="h-5 w-5" />
              {getTotalPendingCount() > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white shadow-md">
                  {getTotalPendingCount() > 9 ? "9+" : getTotalPendingCount()}
                </span>
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onLogout}
              className="text-white hover:bg-white/20"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 space-y-6 p-5">
        {/* Section Header */}
        <div>
          <h2 className="text-xl font-bold text-primary">Pending Requests</h2>
          <p className="mt-1 text-sm text-foreground/60">
            {getTotalPendingCount()} {getTotalPendingCount() === 1 ? "request" : "requests"} awaiting your approval
          </p>
        </div>

        {/* T-Code Categories Grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {tCodeCategories.map((category) => {
            const IconComponent = iconMap[category.icon] || Tag
            const counts = getTCodeStatusCounts(category.code)
            const pendingCount = counts.pending

            return (
              <Card
                key={category.code}
                className={`group cursor-pointer border-primary/10 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 active:scale-95 bg-gradient-to-br from-white to-primary/5 ${
                  pendingCount === 0 ? "opacity-50 pointer-events-none" : ""
                }`}
                onClick={() => pendingCount > 0 && onSelectCategory(category.code)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-md transition-transform group-hover:scale-110 border border-primary/10">
                      <IconComponent className="h-6 w-6 text-primary" />
                    </div>
                    {pendingCount > 0 && (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-yellow-500 text-white text-xs font-bold shadow-md">
                        {pendingCount}
                      </div>
                    )}
                  </div>
                  <h3 className="font-semibold text-foreground">
                    {category.name}
                  </h3>
                  <p className="mt-1 text-sm text-foreground/60">
                    {category.description}
                  </p>
                  {pendingCount > 0 && (
                    <p className="mt-3 text-xs font-medium text-yellow-600">
                      {pendingCount} {pendingCount === 1 ? "request" : "requests"} pending
                    </p>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      </main>
    </div>
  )
}
