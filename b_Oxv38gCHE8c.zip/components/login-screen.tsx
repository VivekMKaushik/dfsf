"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"
import { Fingerprint, Eye, EyeOff, Lock, User } from "lucide-react"
import Image from "next/image"

interface LoginScreenProps {
  onLogin: () => void
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 800))
    setIsLoading(false)
    onLogin()
  }

  const handleBiometricLogin = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 600))
    setIsLoading(false)
    onLogin()
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-md">
        {/* Header Section */}
        <div className="mb-12 text-center">
          <div className="mb-6 flex justify-center">
            <Image
              src="/prestige-logo.png"
              alt="Prestige Group"
              width={80}
              height={80}
              className="drop-shadow-sm"
            />
          </div>
          <h1 className="text-3xl font-bold text-primary tracking-tight">Prestige</h1>
          <p className="mt-2 text-sm font-medium text-primary/70">Approval Center</p>
          <p className="mt-4 text-sm text-foreground/60">
            Streamline your approval workflow with premium efficiency
          </p>
        </div>

        {/* Login Card */}
        <Card className="border border-primary/10 shadow-lg backdrop-blur-sm bg-white/95">
          <CardContent className="pt-8 pb-8">
            <form onSubmit={handleLogin} className="space-y-6">
              <FieldGroup>
                <Field>
                  <FieldLabel htmlFor="username" className="font-medium text-primary">
                    Username
                  </FieldLabel>
                  <div className="relative mt-2">
                    <User className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-primary/40" />
                    <Input
                      id="username"
                      type="text"
                      placeholder="Enter your username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="pl-12 bg-background/50 border-primary/20 h-11 text-foreground placeholder:text-foreground/40"
                    />
                  </div>
                </Field>
                <Field>
                  <FieldLabel htmlFor="password" className="font-medium text-primary">
                    Password
                  </FieldLabel>
                  <div className="relative mt-2">
                    <Lock className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-primary/40" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-12 pr-12 bg-background/50 border-primary/20 h-11 text-foreground placeholder:text-foreground/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-primary/40 hover:text-primary transition-colors"
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                </Field>
              </FieldGroup>

              <Button
                type="submit"
                className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-medium rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
                disabled={isLoading}
              >
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-primary/15" />
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-white px-3 text-xs font-medium text-foreground/50 uppercase tracking-wider">
                    Or
                  </span>
                </div>
              </div>

              <Button
                type="button"
                variant="outline"
                className="w-full h-11 border-2 border-primary/20 text-primary hover:bg-primary/5 font-medium rounded-lg transition-all duration-200"
                onClick={handleBiometricLogin}
                disabled={isLoading}
              >
                <Fingerprint className="mr-3 h-5 w-5" />
                Use Biometrics
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="mt-8 text-center text-xs text-foreground/50 font-medium">
          Powered by Prestige Group &amp; SAP Fiori
        </p>
      </div>
    </div>
  )
}
