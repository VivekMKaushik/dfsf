"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  Tag,
  FileMinus,
  UserPen,
  ShoppingCart,
  CreditCard,
  XCircle,
  RotateCcw,
  ChevronRight,
} from "lucide-react"
import type { RequestStatus } from "@/lib/store"
import { tCodeCategories, getCategoryCountsByStatus } from "@/lib/store"

interface CategoryListScreenProps {
  status: RequestStatus
  onBack: () => void
  onSelectCategory: (tCode: string) => void
}

const statusLabels: Record<RequestStatus, string> = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
  clarification: "Clarification Required",
}

const statusColors: Record<RequestStatus, { bg: string; text: string; badge: string }> = {
  pending: { bg: "from-yellow-50 to-yellow-100/30", text: "text-yellow-600", badge: "bg-yellow-500" },
  approved: { bg: "from-green-50 to-green-100/30", text: "text-green-600", badge: "bg-green-500" },
  rejected: { bg: "from-red-50 to-red-100/30", text: "text-red-600", badge: "bg-red-500" },
  clarification: { bg: "from-blue-50 to-blue-100/30", text: "text-blue-600", badge: "bg-blue-500" },
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  tag: Tag,
  "file-minus": FileMinus,
  "user-pen": UserPen,
  "shopping-cart": ShoppingCart,
  "credit-card": CreditCard,
  "x-circle": XCircle,
  "rotate-ccw": RotateCcw,
}

export function CategoryListScreen({
  status,
  onBack,
  onSelectCategory,
}: CategoryListScreenProps) {
  const categoryCounts = getCategoryCountsByStatus(status)
  const totalCount = Object.values(categoryCounts).reduce((a, b) => a + b, 0)

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Premium Header */}
      <header className="sticky top-0 z-10 bg-gradient-to-r from-primary to-primary/80 px-4 py-4 shadow-lg">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">
              {statusLabels[status]} Requests
            </h1>
            <p className="text-xs text-white/75">
              {totalCount} {totalCount === 1 ? "request" : "requests"} to review
            </p>
          </div>
          <div
            className={`flex h-9 w-9 items-center justify-center rounded-full text-white font-bold shadow-md ${statusColors[status].badge}`}
          >
            {totalCount}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 space-y-4 p-5">
        <div>
          <h2 className="text-base font-semibold text-primary">
            Request Categories
          </h2>
          <p className="mt-1 text-sm text-foreground/60">
            Browse by transaction type
          </p>
        </div>

        <div className="space-y-3">
          {tCodeCategories.map((category) => {
            const IconComponent = iconMap[category.icon] || Tag
            const count = categoryCounts[category.code] || 0

            return (
              <Card
                key={category.code}
                className={`group cursor-pointer border-primary/10 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 active:scale-95 ${
                  count === 0 ? "opacity-50 pointer-events-none" : ""
                } bg-gradient-to-br ${statusColors[status].bg}`}
                onClick={() => count > 0 && onSelectCategory(category.code)}
              >
                <CardContent className="flex items-center gap-4 p-5">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-md transition-transform group-hover:scale-110`}>
                    <IconComponent className={`h-6 w-6 ${statusColors[status].text}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground truncate">
                        {category.name}
                      </h3>
                      <span className="rounded-full bg-white/60 px-2 py-1 text-[11px] font-mono font-medium text-primary whitespace-nowrap">
                        {category.code}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-foreground/60 truncate">
                      {category.description}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    {count > 0 && (
                      <span
                        className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold text-white shadow-md ${statusColors[status].badge}`}
                      >
                        {count}
                      </span>
                    )}
                    <ChevronRight className={`h-5 w-5 transition-transform group-hover:translate-x-1 ${statusColors[status].text}`} />
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </main>
    </div>
  )
}
