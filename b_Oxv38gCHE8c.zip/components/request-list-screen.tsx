"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, FileText, ChevronRight } from "lucide-react"
import type { RequestStatus, ApprovalRequest } from "@/lib/store"
import { getRequestsByTCodeAndStatus, tCodeCategories } from "@/lib/store"

interface RequestListScreenProps {
  tCode: string
  status: RequestStatus
  onBack: () => void
  onSelectRequest: (requestId: string) => void
}

const statusLabels: Record<RequestStatus, string> = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
  clarification: "Clarification Required",
}

const statusColors: Record<RequestStatus, { bg: string; text: string; badge: string }> = {
  pending: { bg: "from-yellow-50 to-yellow-100/30", text: "text-yellow-600", badge: "bg-yellow-500" },
  approved: { bg: "from-green-50 to-green-100/30", text: "text-green-600", badge: "bg-green-500" },
  rejected: { bg: "from-red-50 to-red-100/30", text: "text-red-600", badge: "bg-red-500" },
  clarification: { bg: "from-blue-50 to-blue-100/30", text: "text-blue-600", badge: "bg-blue-500" },
}

export function RequestListScreen({
  tCode,
  status,
  onBack,
  onSelectRequest,
}: RequestListScreenProps) {
  const requests = getRequestsByTCodeAndStatus(tCode, status)
  const category = tCodeCategories.find((c) => c.code === tCode)

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Premium Header */}
      <header className="sticky top-0 z-10 bg-gradient-to-r from-primary to-primary/80 px-4 py-4 shadow-lg">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">
              {statusLabels[status]}
            </h1>
            <p className="text-xs text-white/75">
              {category?.name} • {requests.length}{" "}
              {requests.length === 1 ? "request" : "requests"}
            </p>
          </div>
          <span
            className={`flex h-9 w-9 items-center justify-center rounded-full text-white font-bold shadow-md ${statusColors[status].badge}`}
          >
            {requests.length}
          </span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 space-y-4 p-5">
        {requests.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <FileText className="h-8 w-8 text-primary/40" />
            </div>
            <h3 className="text-lg font-semibold text-primary">
              No requests found
            </h3>
            <p className="mt-2 text-sm text-foreground/60">
              There are no {statusLabels[status].toLowerCase()} requests in this
              category.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {requests.map((request) => (
              <RequestCard
                key={request.id}
                request={request}
                onClick={() => onSelectRequest(request.id)}
                statusColor={statusColors[status]}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

function RequestCard({
  request,
  onClick,
  statusColor,
}: {
  request: ApprovalRequest
  onClick: () => void
  statusColor: { bg: string; text: string; badge: string }
}) {
  return (
    <Card
      className={`group cursor-pointer border-primary/10 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 active:scale-95 bg-gradient-to-br ${statusColor.bg}`}
      onClick={onClick}
    >
      <CardContent className="flex items-center gap-4 p-5">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-md transition-transform group-hover:scale-110">
          <FileText className={`h-6 w-6 ${statusColor.text}`} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground">
            {request.requestNumber}
          </h3>
          <p className="mt-1 text-sm text-foreground/60 truncate">
            {request.requestType}
          </p>
          {request.customerName && (
            <p className="mt-0.5 text-xs text-foreground/50">
              {request.customerName}
            </p>
          )}
        </div>
        <ChevronRight className={`h-5 w-5 transition-transform group-hover:translate-x-1 ${statusColor.text}`} />
      </CardContent>
    </Card>
  )
}
