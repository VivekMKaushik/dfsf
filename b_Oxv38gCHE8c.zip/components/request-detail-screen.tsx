"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  ArrowLeft,
  CheckCircle,
  XCircle,
  User,
  Calendar,
  FileText,
  DollarSign,
  Building,
  Clock,
  MapPin,
  Mail,
  Phone,
  Ruler,
} from "lucide-react"
import type { ApprovalRequest, RequestStatus } from "@/lib/store"
import { getRequestById } from "@/lib/store"

interface RequestDetailScreenProps {
  requestId: string
  onBack: () => void
  onAction: (action: "approve" | "reject") => void
}

const statusConfig: Record<
  RequestStatus,
  { label: string; bgClass: string; textClass: string; badge: string }
> = {
  pending: {
    label: "Pending",
    bgClass: "bg-yellow-100",
    textClass: "text-yellow-700",
    badge: "bg-yellow-500",
  },
  approved: {
    label: "Approved",
    bgClass: "bg-green-100",
    textClass: "text-green-700",
    badge: "bg-green-500",
  },
  rejected: {
    label: "Rejected",
    bgClass: "bg-red-100",
    textClass: "text-red-700",
    badge: "bg-red-500",
  },
  clarification: {
    label: "Clarification Required",
    bgClass: "bg-blue-100",
    textClass: "text-blue-700",
    badge: "bg-blue-500",
  },
}

export function RequestDetailScreen({
  requestId,
  onBack,
  onAction,
}: RequestDetailScreenProps) {
  const request = getRequestById(requestId)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [dialogAction, setDialogAction] = useState<
    "approve" | "reject" | null
  >(null)
  const [comment, setComment] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  if (!request) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Request not found</p>
      </div>
    )
  }

  const handleActionClick = (action: "approve" | "reject") => {
    setDialogAction(action)
    setDialogOpen(true)
  }

  const handleConfirm = async () => {
    if (!dialogAction) return
    setIsProcessing(true)
    // Simulate processing
    await new Promise((resolve) => setTimeout(resolve, 800))
    setIsProcessing(false)
    setDialogOpen(false)
    setComment("")
    onAction(dialogAction)
  }

  const getDialogConfig = () => {
    switch (dialogAction) {
      case "approve":
        return {
          title: "Approve Request",
          description: `Are you sure you want to approve request ${request.requestNumber}?`,
          buttonText: "Approve",
          buttonClass: "bg-green-500 hover:bg-green-600 text-white",
        }
      case "reject":
        return {
          title: "Reject Request",
          description: `Are you sure you want to reject request ${request.requestNumber}?`,
          buttonText: "Reject",
          buttonClass: "bg-red-500 hover:bg-red-600 text-white",
        }
      default:
        return {
          title: "",
          description: "",
          buttonText: "",
          buttonClass: "",
        }
    }
  }

  const dialogConfig = getDialogConfig()
  const statusInfo = statusConfig[request.status]

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Premium Header */}
      <header className="sticky top-0 z-10 bg-gradient-to-r from-primary to-primary/80 px-4 py-4 shadow-lg">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <h1 className="font-semibold text-white text-lg">
              {request.requestNumber}
            </h1>
            <p className="text-xs text-white/75">{request.requestType}</p>
          </div>
          <span
            className={`rounded-full px-3 py-1 text-xs font-semibold text-white ${statusInfo.badge}`}
          >
            {statusInfo.label}
          </span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-auto space-y-4 p-5 pb-40">
        {/* Unit Details Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Unit Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={FileText}
              label="Request Number"
              value={request.requestNumber}
            />
            <DetailRow
              icon={Clock}
              label="Sequence"
              value="1"
            />
            <DetailRow
              icon={Building}
              label="Project Code/Name"
              value={request.projectName || "Prestige Raintree Park"}
            />
            <DetailRow
              icon={Building}
              label="Unit Number"
              value={request.unitNo || "PRP-01-081"}
            />
            <DetailRow
              icon={Ruler}
              label="Area"
              value={request.area || "2533 Sq. Ft"}
            />
          </CardContent>
        </Card>

        {/* Transfer/Cancellation Details Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Cancellation Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={FileText}
              label="Request Type"
              value="40 - Cancellation"
            />
            <DetailRow
              icon={DollarSign}
              label="Bal Payable"
              value="₹2,144,134.00"
            />
            <DetailRow
              icon={Building}
              label="Buyer Type"
              value="Buyer"
            />
          </CardContent>
        </Card>

        {/* Financial Details Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Financial Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={DollarSign}
              label="Sale Value"
              value={`₹${request.saleValue || "34,099,000.00"}`}
            />
            <DetailRow
              icon={DollarSign}
              label="Sale Value per Sq. Ft"
              value={`₹${request.saleValuePerSqFt || "13,462.00"}`}
            />
            <DetailRow
              icon={DollarSign}
              label="Assignment Value"
              value={`₹${request.assignmentValue || "0.00"}`}
            />
            <DetailRow
              icon={DollarSign}
              label="Difference"
              value={`₹${request.difference || "0.00"}`}
            />
            <DetailRow
              icon={DollarSign}
              label="To be Billed"
              value={`₹${request.toBeBilled || "18,378,720.00"}`}
            />
            <DetailRow
              icon={DollarSign}
              label="Unbilled Amount"
              value={`₹${request.unbilledAmount || "0.00"}`}
            />
          </CardContent>
        </Card>

        {/* Contact Information Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Contact Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={User}
              label="Marketing Associate / Channel Partner"
              value={request.submittedBy || "Marketing Associate / Agents"}
            />
            <DetailRow
              icon={User}
              label="Name"
              value={request.contactName || ""}
            />
            <DetailRow
              icon={Mail}
              label="Email"
              value={request.email || ""}
            />
            <DetailRow
              icon={Phone}
              label="Mobile"
              value={request.mobile || ""}
            />
          </CardContent>
        </Card>

        {/* Seller Details Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Seller Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={User}
              label="Customer Code/Name"
              value={request.sellerName || "0100026202 - Kazeena Sompraksah Trivedi"}
            />
          </CardContent>
        </Card>

        {/* Buyer Details Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Buyer Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={User}
              label="Buyer Customer Code"
              value={request.buyerCode || "IB"}
            />
            <DetailRow
              icon={User}
              label="Buyer Customer Name"
              value={request.buyerName || ""}
            />
          </CardContent>
        </Card>

        {/* Receipt Information Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Receipt Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={FileText}
              label="Receipt Number"
              value={request.receiptNo || ""}
            />
            <DetailRow
              icon={Calendar}
              label="Receipt Date"
              value={request.receiptDate || ""}
            />
            <DetailRow
              icon={DollarSign}
              label="Receipt Amount"
              value={`₹${request.receiptAmount || "0.00"}`}
            />
          </CardContent>
        </Card>

        {/* Transfer Charges Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Transfer Charges
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-0 pt-5">
            <DetailRow
              icon={DollarSign}
              label="Total Net Amount"
              value={`₹${request.totalNetAmount || "0.00"}`}
            />
          </CardContent>
        </Card>

        {/* Comments Card */}
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="pb-4 border-b border-primary/10">
            <CardTitle className="text-base font-bold text-primary">
              Comments &amp; Reason
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-5">
            <p className="text-sm leading-relaxed text-foreground/80">
              {request.description || "No comments provided"}
            </p>
          </CardContent>
        </Card>
      </main>

      {/* Fixed Action Buttons */}
      {request.status === "pending" && (
        <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-background via-background to-transparent border-t border-primary/10 p-5 pt-8 shadow-2xl">
          <div className="flex gap-3">
            <Button
              className="flex-1 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg h-12 transition-all duration-200 shadow-md hover:shadow-lg flex items-center justify-center"
              size="lg"
              onClick={() => handleActionClick("approve")}
            >
              <CheckCircle className="mr-2 h-6 w-6" />
              <span>Approve</span>
            </Button>
            <Button
              className="flex-1 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg h-12 transition-all duration-200 shadow-md hover:shadow-lg flex items-center justify-center"
              size="lg"
              onClick={() => handleActionClick("reject")}
            >
              <XCircle className="mr-2 h-6 w-6" />
              <span>Reject</span>
            </Button>
          </div>
        </div>
      )}

      {/* Confirmation Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="mx-4 max-w-sm rounded-xl">
          <DialogHeader>
            <DialogTitle>{dialogConfig.title}</DialogTitle>
            <DialogDescription>{dialogConfig.description}</DialogDescription>
          </DialogHeader>

          {dialogAction === "reject" && (
            <div className="py-2">
              <Textarea
                placeholder="Enter reason for rejection..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
              />
            </div>
          )}

          <DialogFooter className="flex-row gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => setDialogOpen(false)}
              disabled={isProcessing}
            >
              Cancel
            </Button>
            <Button
              className={`flex-1 ${dialogConfig.buttonClass}`}
              onClick={handleConfirm}
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : dialogConfig.buttonText}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function DetailRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
}) {
  return (
    <div className="flex items-start gap-4 pb-4 border-b border-primary/10 last:border-0 last:pb-0">
      <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-primary/10">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-medium text-foreground/50 uppercase tracking-wide">{label}</p>
        <p className="mt-1 text-sm font-semibold text-foreground">{value}</p>
      </div>
    </div>
  )
}
