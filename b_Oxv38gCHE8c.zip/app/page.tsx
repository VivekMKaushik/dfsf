"use client"

import { useState } from "react"
import { LoginScreen } from "@/components/login-screen"
import { DashboardScreen } from "@/components/dashboard-screen"
import { RequestListScreen } from "@/components/request-list-screen"
import { RequestDetailScreen } from "@/components/request-detail-screen"
import { Toaster } from "@/components/ui/sonner"
import { toast } from "sonner"

type Screen =
  | "login"
  | "dashboard"
  | "requestList"
  | "requestDetail"

interface NavigationState {
  screen: Screen
  status?: RequestStatus
  tCode?: string
  requestId?: string
}

export default function ApprovalDashboard() {
  const [navState, setNavState] = useState<NavigationState>({
    screen: "login",
  })

  // Navigation handlers
  const handleLogin = () => {
    setNavState({ screen: "dashboard" })
  }

  const handleLogout = () => {
    setNavState({ screen: "login" })
  }

  const handleSelectCategory = (tCode: string) => {
    // Navigate to request list for pending status in selected T-code
    setNavState({ screen: "requestList", status: "pending", tCode })
  }

  const handleSelectRequest = (requestId: string) => {
    setNavState({
      screen: "requestDetail",
      status: navState.status,
      tCode: navState.tCode,
      requestId,
    })
  }

  const handleAction = (action: "approve" | "reject") => {
    const messages = {
      approve: "Request approved successfully",
      reject: "Request rejected",
    }
    toast.success(messages[action])
    
    // Go back to request list
    setNavState({
      screen: "requestList",
      status: navState.status,
      tCode: navState.tCode,
    })
  }

  const handleBackToDashboard = () => {
    setNavState({ screen: "dashboard" })
  }



  const handleBackToRequestList = () => {
    setNavState({
      screen: "requestList",
      status: navState.status,
      tCode: navState.tCode,
    })
  }

  // Render screens based on navigation state
  const renderScreen = () => {
    switch (navState.screen) {
      case "login":
        return <LoginScreen onLogin={handleLogin} />

      case "dashboard":
        return (
          <DashboardScreen
            onSelectCategory={handleSelectCategory}
            onLogout={handleLogout}
          />
        )

      case "requestList":
        return (
          <RequestListScreen
            tCode={navState.tCode!}
            status={navState.status!}
            onBack={handleBackToDashboard}
            onSelectRequest={handleSelectRequest}
          />
        )

      case "requestDetail":
        return (
          <RequestDetailScreen
            requestId={navState.requestId!}
            onBack={handleBackToRequestList}
            onAction={handleAction}
          />
        )

      default:
        return <LoginScreen onLogin={handleLogin} />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {renderScreen()}
      <Toaster position="top-center" />
    </div>
  )
}
